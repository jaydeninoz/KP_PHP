<?php 

    $con = mysqli_connect('localhost', 'root', '', 'kp_php');
    mysqli_set_charset($con, 'utf8');

    $username = $_POST['username'];

    $queryString = "SELECT * FROM usernames WHERE username = '$username'";
    $result = mysqli_query($con, $queryString);
    $row = mysqli_fetch_assoc($result);

    $invalid = "The username is not available";
    $valid = "You can use this username";

    if (count($row) > 0)  {
        echo $invalid;
    } else {
        echo $valid;
    }

?>